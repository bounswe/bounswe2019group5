--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Debian 11.5-3.pgdg90+1)
-- Dumped by pg_dump version 11.5 (Debian 11.5-3.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: api_annotation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_annotation (
    id integer NOT NULL,
    context character varying(200) NOT NULL,
    type character varying(11) NOT NULL,
    motivation character varying(8) NOT NULL,
    created timestamp with time zone NOT NULL,
    creator_id integer NOT NULL
);


ALTER TABLE public.api_annotation OWNER TO postgres;

--
-- Name: api_annotation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_annotation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_annotation_id_seq OWNER TO postgres;

--
-- Name: api_annotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_annotation_id_seq OWNED BY public.api_annotation.id;


--
-- Name: api_annotationbody; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_annotationbody (
    id integer NOT NULL,
    type character varying(11) NOT NULL,
    purpose character varying(10) NOT NULL,
    value character varying(1000) NOT NULL,
    annotation_id integer NOT NULL
);


ALTER TABLE public.api_annotationbody OWNER TO postgres;

--
-- Name: api_annotationbody_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_annotationbody_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_annotationbody_id_seq OWNER TO postgres;

--
-- Name: api_annotationbody_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_annotationbody_id_seq OWNED BY public.api_annotationbody.id;


--
-- Name: api_annotationselector; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_annotationselector (
    id integer NOT NULL,
    type character varying(16) NOT NULL,
    "conformsTo" character varying(1000) NOT NULL,
    value character varying(1000) NOT NULL,
    target_id integer NOT NULL
);


ALTER TABLE public.api_annotationselector OWNER TO postgres;

--
-- Name: api_annotationselector_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_annotationselector_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_annotationselector_id_seq OWNER TO postgres;

--
-- Name: api_annotationselector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_annotationselector_id_seq OWNED BY public.api_annotationselector.id;


--
-- Name: api_annotationtarget; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_annotationtarget (
    id integer NOT NULL,
    annotation_id integer NOT NULL,
    source_id integer NOT NULL
);


ALTER TABLE public.api_annotationtarget OWNER TO postgres;

--
-- Name: api_annotationtarget_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_annotationtarget_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_annotationtarget_id_seq OWNER TO postgres;

--
-- Name: api_annotationtarget_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_annotationtarget_id_seq OWNED BY public.api_annotationtarget.id;


--
-- Name: api_comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_comment (
    id integer NOT NULL,
    username character varying(20) NOT NULL,
    comment character varying(1000) NOT NULL,
    rate integer NOT NULL,
    commented_user_id integer NOT NULL
);


ALTER TABLE public.api_comment OWNER TO postgres;

--
-- Name: api_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_comment_id_seq OWNER TO postgres;

--
-- Name: api_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_comment_id_seq OWNED BY public.api_comment.id;


--
-- Name: api_essay; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_essay (
    exam_ptr_id integer NOT NULL,
    writing character varying(100) NOT NULL,
    author_id integer NOT NULL,
    reviewer_id integer,
    status character varying(9) NOT NULL,
    date timestamp with time zone NOT NULL
);


ALTER TABLE public.api_essay OWNER TO postgres;

--
-- Name: api_exam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_exam (
    id integer NOT NULL,
    type character varying(11) NOT NULL,
    language character varying(20) NOT NULL
);


ALTER TABLE public.api_exam OWNER TO postgres;

--
-- Name: api_exam_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_exam_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_exam_id_seq OWNER TO postgres;

--
-- Name: api_exam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_exam_id_seq OWNED BY public.api_exam.id;


--
-- Name: api_exercise; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_exercise (
    exam_ptr_id integer NOT NULL,
    level character varying(2) NOT NULL,
    tags character varying(25)[],
    keywords character varying(25)[],
    is_published boolean NOT NULL
);


ALTER TABLE public.api_exercise OWNER TO postgres;

--
-- Name: api_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_file (
    id integer NOT NULL,
    file character varying(100) NOT NULL,
    created_date timestamp with time zone NOT NULL
);


ALTER TABLE public.api_file OWNER TO postgres;

--
-- Name: api_file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_file_id_seq OWNER TO postgres;

--
-- Name: api_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_file_id_seq OWNED BY public.api_file.id;


--
-- Name: api_language; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_language (
    id integer NOT NULL,
    language character varying(20) NOT NULL
);


ALTER TABLE public.api_language OWNER TO postgres;

--
-- Name: api_language_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_language_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_language_id_seq OWNER TO postgres;

--
-- Name: api_language_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_language_id_seq OWNED BY public.api_language.id;


--
-- Name: api_message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_message (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    text character varying(1000) NOT NULL,
    owner_id integer NOT NULL,
    username_id integer NOT NULL
);


ALTER TABLE public.api_message OWNER TO postgres;

--
-- Name: api_message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_message_id_seq OWNER TO postgres;

--
-- Name: api_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_message_id_seq OWNED BY public.api_message.id;


--
-- Name: api_question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_question (
    id integer NOT NULL,
    answer character varying(1000) NOT NULL,
    options character varying(100)[] NOT NULL,
    body text NOT NULL,
    exam_id integer NOT NULL
);


ALTER TABLE public.api_question OWNER TO postgres;

--
-- Name: api_question_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_question_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_question_id_seq OWNER TO postgres;

--
-- Name: api_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_question_id_seq OWNED BY public.api_question.id;


--
-- Name: api_result; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_result (
    id integer NOT NULL,
    number_of_true integer NOT NULL,
    number_of_false integer NOT NULL,
    user_id integer NOT NULL,
    exercise_id integer NOT NULL
);


ALTER TABLE public.api_result OWNER TO postgres;

--
-- Name: api_result_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_result_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_result_id_seq OWNER TO postgres;

--
-- Name: api_result_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_result_id_seq OWNED BY public.api_result.id;


--
-- Name: api_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL,
    native_language character varying(20) NOT NULL,
    rating_average double precision NOT NULL,
    levels jsonb NOT NULL
);


ALTER TABLE public.api_user OWNER TO postgres;

--
-- Name: api_user_attended_languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_user_attended_languages (
    id integer NOT NULL,
    user_id integer NOT NULL,
    language_id integer NOT NULL
);


ALTER TABLE public.api_user_attended_languages OWNER TO postgres;

--
-- Name: api_user_attended_languages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_user_attended_languages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_user_attended_languages_id_seq OWNER TO postgres;

--
-- Name: api_user_attended_languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_user_attended_languages_id_seq OWNED BY public.api_user_attended_languages.id;


--
-- Name: api_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.api_user_groups OWNER TO postgres;

--
-- Name: api_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_user_groups_id_seq OWNER TO postgres;

--
-- Name: api_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_user_groups_id_seq OWNED BY public.api_user_groups.id;


--
-- Name: api_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_user_id_seq OWNER TO postgres;

--
-- Name: api_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_user_id_seq OWNED BY public.api_user.id;


--
-- Name: api_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.api_user_user_permissions OWNER TO postgres;

--
-- Name: api_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: api_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_user_user_permissions_id_seq OWNED BY public.api_user_user_permissions.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO postgres;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: api_annotation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotation ALTER COLUMN id SET DEFAULT nextval('public.api_annotation_id_seq'::regclass);


--
-- Name: api_annotationbody id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationbody ALTER COLUMN id SET DEFAULT nextval('public.api_annotationbody_id_seq'::regclass);


--
-- Name: api_annotationselector id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationselector ALTER COLUMN id SET DEFAULT nextval('public.api_annotationselector_id_seq'::regclass);


--
-- Name: api_annotationtarget id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationtarget ALTER COLUMN id SET DEFAULT nextval('public.api_annotationtarget_id_seq'::regclass);


--
-- Name: api_comment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_comment ALTER COLUMN id SET DEFAULT nextval('public.api_comment_id_seq'::regclass);


--
-- Name: api_exam id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_exam ALTER COLUMN id SET DEFAULT nextval('public.api_exam_id_seq'::regclass);


--
-- Name: api_file id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_file ALTER COLUMN id SET DEFAULT nextval('public.api_file_id_seq'::regclass);


--
-- Name: api_language id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_language ALTER COLUMN id SET DEFAULT nextval('public.api_language_id_seq'::regclass);


--
-- Name: api_message id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_message ALTER COLUMN id SET DEFAULT nextval('public.api_message_id_seq'::regclass);


--
-- Name: api_question id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_question ALTER COLUMN id SET DEFAULT nextval('public.api_question_id_seq'::regclass);


--
-- Name: api_result id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_result ALTER COLUMN id SET DEFAULT nextval('public.api_result_id_seq'::regclass);


--
-- Name: api_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user ALTER COLUMN id SET DEFAULT nextval('public.api_user_id_seq'::regclass);


--
-- Name: api_user_attended_languages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_attended_languages ALTER COLUMN id SET DEFAULT nextval('public.api_user_attended_languages_id_seq'::regclass);


--
-- Name: api_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_groups ALTER COLUMN id SET DEFAULT nextval('public.api_user_groups_id_seq'::regclass);


--
-- Name: api_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.api_user_user_permissions_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: api_annotation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_annotation (id, context, type, motivation, created, creator_id) FROM stdin;
\.
COPY public.api_annotation (id, context, type, motivation, created, creator_id) FROM '$$PATH$$/3174.dat';

--
-- Data for Name: api_annotationbody; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_annotationbody (id, type, purpose, value, annotation_id) FROM stdin;
\.
COPY public.api_annotationbody (id, type, purpose, value, annotation_id) FROM '$$PATH$$/3189.dat';

--
-- Data for Name: api_annotationselector; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_annotationselector (id, type, "conformsTo", value, target_id) FROM stdin;
\.
COPY public.api_annotationselector (id, type, "conformsTo", value, target_id) FROM '$$PATH$$/3187.dat';

--
-- Data for Name: api_annotationtarget; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_annotationtarget (id, annotation_id, source_id) FROM stdin;
\.
COPY public.api_annotationtarget (id, annotation_id, source_id) FROM '$$PATH$$/3185.dat';

--
-- Data for Name: api_comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_comment (id, username, comment, rate, commented_user_id) FROM stdin;
\.
COPY public.api_comment (id, username, comment, rate, commented_user_id) FROM '$$PATH$$/3183.dat';

--
-- Data for Name: api_essay; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_essay (exam_ptr_id, writing, author_id, reviewer_id, status, date) FROM stdin;
\.
COPY public.api_essay (exam_ptr_id, writing, author_id, reviewer_id, status, date) FROM '$$PATH$$/3198.dat';

--
-- Data for Name: api_exam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_exam (id, type, language) FROM stdin;
\.
COPY public.api_exam (id, type, language) FROM '$$PATH$$/3176.dat';

--
-- Data for Name: api_exercise; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_exercise (exam_ptr_id, level, tags, keywords, is_published) FROM stdin;
\.
COPY public.api_exercise (exam_ptr_id, level, tags, keywords, is_published) FROM '$$PATH$$/3179.dat';

--
-- Data for Name: api_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_file (id, file, created_date) FROM stdin;
\.
COPY public.api_file (id, file, created_date) FROM '$$PATH$$/3206.dat';

--
-- Data for Name: api_language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_language (id, language) FROM stdin;
\.
COPY public.api_language (id, language) FROM '$$PATH$$/3178.dat';

--
-- Data for Name: api_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_message (id, date, text, owner_id, username_id) FROM stdin;
\.
COPY public.api_message (id, date, text, owner_id, username_id) FROM '$$PATH$$/3181.dat';

--
-- Data for Name: api_question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_question (id, answer, options, body, exam_id) FROM stdin;
\.
COPY public.api_question (id, answer, options, body, exam_id) FROM '$$PATH$$/3197.dat';

--
-- Data for Name: api_result; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_result (id, number_of_true, number_of_false, user_id, exercise_id) FROM stdin;
\.
COPY public.api_result (id, number_of_true, number_of_false, user_id, exercise_id) FROM '$$PATH$$/3200.dat';

--
-- Data for Name: api_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_user (id, password, last_login, is_superuser, username, first_name, last_name, is_staff, is_active, date_joined, email, native_language, rating_average, levels) FROM stdin;
\.
COPY public.api_user (id, password, last_login, is_superuser, username, first_name, last_name, is_staff, is_active, date_joined, email, native_language, rating_average, levels) FROM '$$PATH$$/3172.dat';

--
-- Data for Name: api_user_attended_languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_user_attended_languages (id, user_id, language_id) FROM stdin;
\.
COPY public.api_user_attended_languages (id, user_id, language_id) FROM '$$PATH$$/3191.dat';

--
-- Data for Name: api_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.api_user_groups (id, user_id, group_id) FROM '$$PATH$$/3193.dat';

--
-- Data for Name: api_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.api_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3195.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3168.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3170.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3166.dat';

--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.
COPY public.authtoken_token (key, created, user_id) FROM '$$PATH$$/3203.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3202.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3164.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3162.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3204.dat';

--
-- Name: api_annotation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_annotation_id_seq', 201, true);


--
-- Name: api_annotationbody_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_annotationbody_id_seq', 201, true);


--
-- Name: api_annotationselector_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_annotationselector_id_seq', 201, true);


--
-- Name: api_annotationtarget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_annotationtarget_id_seq', 201, true);


--
-- Name: api_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_comment_id_seq', 20, true);


--
-- Name: api_exam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_exam_id_seq', 230, true);


--
-- Name: api_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_file_id_seq', 39, true);


--
-- Name: api_language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_language_id_seq', 6, true);


--
-- Name: api_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_message_id_seq', 344, true);


--
-- Name: api_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_question_id_seq', 144, true);


--
-- Name: api_result_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_result_id_seq', 298, true);


--
-- Name: api_user_attended_languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_user_attended_languages_id_seq', 94, true);


--
-- Name: api_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_user_groups_id_seq', 1, false);


--
-- Name: api_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_user_id_seq', 148, true);


--
-- Name: api_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_user_user_permissions_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 80, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 458, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 20, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 30, true);


--
-- Name: api_annotation api_annotation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotation
    ADD CONSTRAINT api_annotation_pkey PRIMARY KEY (id);


--
-- Name: api_annotationbody api_annotationbody_annotation_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationbody
    ADD CONSTRAINT api_annotationbody_annotation_id_key UNIQUE (annotation_id);


--
-- Name: api_annotationbody api_annotationbody_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationbody
    ADD CONSTRAINT api_annotationbody_pkey PRIMARY KEY (id);


--
-- Name: api_annotationselector api_annotationselector_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationselector
    ADD CONSTRAINT api_annotationselector_pkey PRIMARY KEY (id);


--
-- Name: api_annotationselector api_annotationselector_target_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationselector
    ADD CONSTRAINT api_annotationselector_target_id_key UNIQUE (target_id);


--
-- Name: api_annotationtarget api_annotationtarget_annotation_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationtarget
    ADD CONSTRAINT api_annotationtarget_annotation_id_key UNIQUE (annotation_id);


--
-- Name: api_annotationtarget api_annotationtarget_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationtarget
    ADD CONSTRAINT api_annotationtarget_pkey PRIMARY KEY (id);


--
-- Name: api_comment api_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_comment
    ADD CONSTRAINT api_comment_pkey PRIMARY KEY (id);


--
-- Name: api_essay api_essay_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_essay
    ADD CONSTRAINT api_essay_pkey PRIMARY KEY (exam_ptr_id);


--
-- Name: api_exam api_exam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_exam
    ADD CONSTRAINT api_exam_pkey PRIMARY KEY (id);


--
-- Name: api_exercise api_exercise_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_exercise
    ADD CONSTRAINT api_exercise_pkey PRIMARY KEY (exam_ptr_id);


--
-- Name: api_file api_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_file
    ADD CONSTRAINT api_file_pkey PRIMARY KEY (id);


--
-- Name: api_language api_language_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_language
    ADD CONSTRAINT api_language_pkey PRIMARY KEY (id);


--
-- Name: api_message api_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_message
    ADD CONSTRAINT api_message_pkey PRIMARY KEY (id);


--
-- Name: api_question api_question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_question
    ADD CONSTRAINT api_question_pkey PRIMARY KEY (id);


--
-- Name: api_result api_result_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_result
    ADD CONSTRAINT api_result_pkey PRIMARY KEY (id);


--
-- Name: api_result api_result_user_id_exercise_id_48e3e569_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_result
    ADD CONSTRAINT api_result_user_id_exercise_id_48e3e569_uniq UNIQUE (user_id, exercise_id);


--
-- Name: api_user_attended_languages api_user_attended_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_attended_languages
    ADD CONSTRAINT api_user_attended_languages_pkey PRIMARY KEY (id);


--
-- Name: api_user_attended_languages api_user_attended_languages_user_id_language_id_6dfea44b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_attended_languages
    ADD CONSTRAINT api_user_attended_languages_user_id_language_id_6dfea44b_uniq UNIQUE (user_id, language_id);


--
-- Name: api_user api_user_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user
    ADD CONSTRAINT api_user_email_key UNIQUE (email);


--
-- Name: api_user_groups api_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_groups
    ADD CONSTRAINT api_user_groups_pkey PRIMARY KEY (id);


--
-- Name: api_user_groups api_user_groups_user_id_group_id_9c7ddfb5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_groups
    ADD CONSTRAINT api_user_groups_user_id_group_id_9c7ddfb5_uniq UNIQUE (user_id, group_id);


--
-- Name: api_user api_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user
    ADD CONSTRAINT api_user_pkey PRIMARY KEY (id);


--
-- Name: api_user_user_permissions api_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_user_permissions
    ADD CONSTRAINT api_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: api_user_user_permissions api_user_user_permissions_user_id_permission_id_a06dd704_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_user_permissions
    ADD CONSTRAINT api_user_user_permissions_user_id_permission_id_a06dd704_uniq UNIQUE (user_id, permission_id);


--
-- Name: api_user api_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user
    ADD CONSTRAINT api_user_username_key UNIQUE (username);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: api_annotation_creator_id_cc46c8a7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_annotation_creator_id_cc46c8a7 ON public.api_annotation USING btree (creator_id);


--
-- Name: api_annotationtarget_source_id_5676bfbc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_annotationtarget_source_id_5676bfbc ON public.api_annotationtarget USING btree (source_id);


--
-- Name: api_comment_commented_user_id_b3a52814; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_comment_commented_user_id_b3a52814 ON public.api_comment USING btree (commented_user_id);


--
-- Name: api_essay_author_id_1b68e41f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_essay_author_id_1b68e41f ON public.api_essay USING btree (author_id);


--
-- Name: api_essay_reviewer_id_a346b6e0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_essay_reviewer_id_a346b6e0 ON public.api_essay USING btree (reviewer_id);


--
-- Name: api_message_owner_id_e3f240a3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_message_owner_id_e3f240a3 ON public.api_message USING btree (owner_id);


--
-- Name: api_message_username_id_6d671a1a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_message_username_id_6d671a1a ON public.api_message USING btree (username_id);


--
-- Name: api_question_exam_id_54a51384; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_question_exam_id_54a51384 ON public.api_question USING btree (exam_id);


--
-- Name: api_result_exercise_id_8983768f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_result_exercise_id_8983768f ON public.api_result USING btree (exercise_id);


--
-- Name: api_result_user_id_6ba05b76; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_result_user_id_6ba05b76 ON public.api_result USING btree (user_id);


--
-- Name: api_user_attended_languages_language_id_b3f93d17; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_attended_languages_language_id_b3f93d17 ON public.api_user_attended_languages USING btree (language_id);


--
-- Name: api_user_attended_languages_user_id_923dfbab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_attended_languages_user_id_923dfbab ON public.api_user_attended_languages USING btree (user_id);


--
-- Name: api_user_email_9ef5afa6_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_email_9ef5afa6_like ON public.api_user USING btree (email varchar_pattern_ops);


--
-- Name: api_user_groups_group_id_3af85785; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_groups_group_id_3af85785 ON public.api_user_groups USING btree (group_id);


--
-- Name: api_user_groups_user_id_a5ff39fa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_groups_user_id_a5ff39fa ON public.api_user_groups USING btree (user_id);


--
-- Name: api_user_user_permissions_permission_id_305b7fea; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_user_permissions_permission_id_305b7fea ON public.api_user_user_permissions USING btree (permission_id);


--
-- Name: api_user_user_permissions_user_id_f3945d65; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_user_permissions_user_id_f3945d65 ON public.api_user_user_permissions USING btree (user_id);


--
-- Name: api_user_username_cf4e88d2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_user_username_cf4e88d2_like ON public.api_user USING btree (username varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: api_annotation api_annotation_creator_id_cc46c8a7_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotation
    ADD CONSTRAINT api_annotation_creator_id_cc46c8a7_fk_api_user_id FOREIGN KEY (creator_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_annotationbody api_annotationbody_annotation_id_ede945e4_fk_api_annotation_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationbody
    ADD CONSTRAINT api_annotationbody_annotation_id_ede945e4_fk_api_annotation_id FOREIGN KEY (annotation_id) REFERENCES public.api_annotation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_annotationselector api_annotationselect_target_id_21d41658_fk_api_annot; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationselector
    ADD CONSTRAINT api_annotationselect_target_id_21d41658_fk_api_annot FOREIGN KEY (target_id) REFERENCES public.api_annotationtarget(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_annotationtarget api_annotationtarget_annotation_id_c3519fc0_fk_api_annot; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationtarget
    ADD CONSTRAINT api_annotationtarget_annotation_id_c3519fc0_fk_api_annot FOREIGN KEY (annotation_id) REFERENCES public.api_annotation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_annotationtarget api_annotationtarget_source_id_5676bfbc_fk_api_essay; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_annotationtarget
    ADD CONSTRAINT api_annotationtarget_source_id_5676bfbc_fk_api_essay FOREIGN KEY (source_id) REFERENCES public.api_essay(exam_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_comment api_comment_commented_user_id_b3a52814_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_comment
    ADD CONSTRAINT api_comment_commented_user_id_b3a52814_fk_api_user_id FOREIGN KEY (commented_user_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_essay api_essay_author_id_1b68e41f_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_essay
    ADD CONSTRAINT api_essay_author_id_1b68e41f_fk_api_user_id FOREIGN KEY (author_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_essay api_essay_exam_ptr_id_93f9eefa_fk_api_exam_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_essay
    ADD CONSTRAINT api_essay_exam_ptr_id_93f9eefa_fk_api_exam_id FOREIGN KEY (exam_ptr_id) REFERENCES public.api_exam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_essay api_essay_reviewer_id_a346b6e0_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_essay
    ADD CONSTRAINT api_essay_reviewer_id_a346b6e0_fk_api_user_id FOREIGN KEY (reviewer_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_exercise api_exercise_exam_ptr_id_91e2c8f8_fk_api_exam_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_exercise
    ADD CONSTRAINT api_exercise_exam_ptr_id_91e2c8f8_fk_api_exam_id FOREIGN KEY (exam_ptr_id) REFERENCES public.api_exam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_message api_message_owner_id_e3f240a3_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_message
    ADD CONSTRAINT api_message_owner_id_e3f240a3_fk_api_user_id FOREIGN KEY (owner_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_message api_message_username_id_6d671a1a_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_message
    ADD CONSTRAINT api_message_username_id_6d671a1a_fk_api_user_id FOREIGN KEY (username_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_question api_question_exam_id_54a51384_fk_api_exercise_exam_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_question
    ADD CONSTRAINT api_question_exam_id_54a51384_fk_api_exercise_exam_ptr_id FOREIGN KEY (exam_id) REFERENCES public.api_exercise(exam_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_result api_result_exercise_id_8983768f_fk_api_exercise_exam_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_result
    ADD CONSTRAINT api_result_exercise_id_8983768f_fk_api_exercise_exam_ptr_id FOREIGN KEY (exercise_id) REFERENCES public.api_exercise(exam_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_result api_result_user_id_6ba05b76_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_result
    ADD CONSTRAINT api_result_user_id_6ba05b76_fk_api_user_id FOREIGN KEY (user_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_user_attended_languages api_user_attended_la_language_id_b3f93d17_fk_api_langu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_attended_languages
    ADD CONSTRAINT api_user_attended_la_language_id_b3f93d17_fk_api_langu FOREIGN KEY (language_id) REFERENCES public.api_language(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_user_attended_languages api_user_attended_languages_user_id_923dfbab_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_attended_languages
    ADD CONSTRAINT api_user_attended_languages_user_id_923dfbab_fk_api_user_id FOREIGN KEY (user_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_user_groups api_user_groups_group_id_3af85785_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_groups
    ADD CONSTRAINT api_user_groups_group_id_3af85785_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_user_groups api_user_groups_user_id_a5ff39fa_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_groups
    ADD CONSTRAINT api_user_groups_user_id_a5ff39fa_fk_api_user_id FOREIGN KEY (user_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_user_user_permissions api_user_user_permis_permission_id_305b7fea_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_user_permissions
    ADD CONSTRAINT api_user_user_permis_permission_id_305b7fea_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_user_user_permissions api_user_user_permissions_user_id_f3945d65_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_user_user_permissions
    ADD CONSTRAINT api_user_user_permissions_user_id_f3945d65_fk_api_user_id FOREIGN KEY (user_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_api_user_id FOREIGN KEY (user_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_api_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_api_user_id FOREIGN KEY (user_id) REFERENCES public.api_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

